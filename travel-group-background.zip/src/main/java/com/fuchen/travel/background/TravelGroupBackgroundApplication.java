package com.fuchen.travel.background;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelGroupBackgroundApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravelGroupBackgroundApplication.class, args);
    }

}
